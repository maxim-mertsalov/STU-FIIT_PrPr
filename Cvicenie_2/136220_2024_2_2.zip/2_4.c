#include <stdio.h>

int main() {
    char a, b;
    scanf("%c %c", &a, &b);

    printf("%c %d \n%c %d \n", a, a, b, b);

    return 0;
}
